package com.example.proyecto_final;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Registro extends AppCompatActivity {

    EditText email, contraseña, repetircontra;

    Button volver, registrarse;

    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        mAuth = FirebaseAuth.getInstance();


        email = findViewById(R.id.registro_Correo);

        contraseña = findViewById(R.id.registro_Contraseña);
        repetircontra = findViewById(R.id.registro_RepetirContra);

        volver = findViewById(R.id.registro_Volver);
        registrarse = findViewById(R.id.registro_CrearCuenta);


        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Registro.this, Login.class));
            }
        });

        registrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isValidEmail(email.getText().toString()) && isValidPassword(contraseña.getText().toString()) && isValidPassword(repetircontra.getText().toString())) {
                    Toast.makeText(Registro.this, "Cuenta creada correctamente", Toast.LENGTH_SHORT).show();

                    RegistrarUsuario(email.getText().toString(),contraseña.getText().toString());

                } else if (!isValidPassword(contraseña.getText().toString()) || isValidEmail(email.getText().toString()) || isValidPassword(repetircontra.getText().toString())) {

                    if (!isValidEmail(email.getText().toString())) {
                        Toast.makeText(Registro.this, "Correo Invalido", Toast.LENGTH_SHORT).show();
                    }
                    if (!isValidPassword(contraseña.getText().toString())) {
                        Toast.makeText(Registro.this, "contraseña invalida", Toast.LENGTH_SHORT).show();
                    } else if (isValidPassword(contraseña.getText().toString()) != isValidPassword(repetircontra.getText().toString())) {
                        Toast.makeText(Registro.this, "La contraseña no coincide", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            private boolean isValidEmail(String email) {
                String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
                Pattern pattern = Pattern.compile(emailRegex);
                Matcher matcher = pattern.matcher(email);
                return matcher.matches();
            }

            private boolean isValidPassword(String password) {
                return password.length() >= 8 &&
                        password.matches(".*[A-Z].*") &&
                        password.matches(".*[a-z].*") &&
                        password.matches(".*\\d.*");
            }
        });
    }

    private void RegistrarUsuario(String email, String contraseña) {
        mAuth.createUserWithEmailAndPassword(email, contraseña).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    finish();
                    startActivity(new Intent(Registro.this,Login.class));
                    Toast.makeText(Registro.this, "Usuario creado correctamente", Toast.LENGTH_SHORT).show();
                }
            }
        });
        {

        }
    }
}
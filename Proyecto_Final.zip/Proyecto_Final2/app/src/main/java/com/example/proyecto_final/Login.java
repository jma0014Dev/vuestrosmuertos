package com.example.proyecto_final;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Firebase;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.database.FirebaseDatabase;

public class Login extends AppCompatActivity {

    Button btn_login, btn_registro ;

    EditText email, pass;

    FirebaseAuth mAuth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();

        email = findViewById(R.id.emailEditText);
        pass = findViewById(R.id.passEditText);

        btn_login = findViewById(R.id.signinBoton);

        btn_registro = findViewById(R.id.registrarBoton);

        btn_registro.setOnClickListener(new View.OnClickListener(){

                                            @Override
                                            public void onClick(View v) {
                                                startActivity(new Intent(Login.this, Registro.class));
                                            }
                                        });

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailUsuario = email.getText().toString();
                String passUsuario = pass.getText().toString();

                if (emailUsuario.isEmpty() || passUsuario.isEmpty()){
                    Toast.makeText(Login.this, "Ingrese un usuario o contraseña",Toast.LENGTH_SHORT).show();
                }else{
                    LoginUser(emailUsuario,passUsuario);
                }
            }

            private void LoginUser(String emailUsuario, String passUsuario) {
                mAuth.signInWithEmailAndPassword(emailUsuario,passUsuario).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            finish();
                            startActivity(new Intent(Login.this, HomeActivity.class));
                            Toast.makeText(Login.this,"Bienvenido",Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(Login.this,"Error",Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Login.this,"Error al iniciar sesión",Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}